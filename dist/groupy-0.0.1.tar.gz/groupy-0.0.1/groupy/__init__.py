"""
A Python library equipped with basic tools to build, sandbox and explore
groupy theory and abstract algebraic objects.
"""

__author__ = "Luke Keating Hughes"

__version__ = "0.0.1"


__email__ = "groupython@gmail.com"

